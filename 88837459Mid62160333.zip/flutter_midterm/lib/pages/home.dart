import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController result = TextEditingController();
  @override
  void initState() {
    result.text = "ยินดีต้อนรับคุณ...";
  }

  Widget build(BuildContext context) {
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(100.0),
          child: Center(
            child: Column(
              children: [
                Image.network(
                  'https://cdn-icons-png.flaticon.com/512/1828/1828503.png',
                  width: 300,
                ),
                SizedBox(
                  height: 30,
                ),
                const Text(
                  'Longin เข้าสู่ระบบ',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                SizedBox(
                  height: 30,
                ),
                TextField(
                  controller: username,
                  decoration: InputDecoration(
                      labelText: 'Username',
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      )),
                ),
                SizedBox(
                  height: 30,
                ),
                TextField(
                  obscureText: true,
                  onChanged: (password) {},
                  obscuringCharacter: "*",
                  decoration: InputDecoration(
                      labelText: 'password',
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      )),
                ),
                SizedBox(
                  height: 30,
                ),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        result.text = "ยินดีต้อนรับคุณ ${username.text}";
                      });
                    },
                    child: Text("เข้าสู่ระบบ"),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        textStyle: MaterialStateProperty.all(
                            TextStyle(fontSize: 25)))),
                SizedBox(
                  height: 30,
                ),
                Text(result.text),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
