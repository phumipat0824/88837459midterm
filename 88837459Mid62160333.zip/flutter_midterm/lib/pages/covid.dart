import 'package:flutter/material.dart';
import 'package:flutter_midterm/pages/home.dart';
import 'dart:convert';
import 'dart:js';
import 'dart:async';
import 'package:http/http.dart' as http;

class CovidPage extends StatefulWidget {
  const CovidPage({Key? key}) : super(key: key);

  @override
  _CovidPageState createState() => _CovidPageState();
}

class _CovidPageState extends State<CovidPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
          padding: EdgeInsets.all(20),
          child: FutureBuilder(
            builder: (context, AsyncSnapshot snapshot) {
              //var data = json.decode(snapshot.data.toString());
              return ListView.builder(
                itemBuilder: (BuildContext context, int index) {
                  return MyBox(snapshot.data[index]['province'],
                      snapshot.data[index]['total_case'], context);
                },
                itemCount: snapshot.data.length,
              );
            },
            future: getData(),
          )),
    );
  }
}

Widget MyBox(String province, int total_case, context) {
  var v1, v2;
  v1 = province;
  v2 = total_case;
  return Container(
    //color: Colors.blueGrey[200],
    margin: EdgeInsets.only(top: 10),
    padding: EdgeInsets.all(10),
    child: ListTile(
      leading: FlutterLogo(),
      title: Text("จังหวัด ${province}  จำนวนผู้ติดเชื้อ ${total_case} คน"),
    ),
  );
}

Future getData() async {
  //https://covid19.ddc.moph.go.th/api/Cases/today-cases-by-provinces
  var url = Uri.https(
      'covid19.ddc.moph.go.th', '/api/Cases/today-cases-by-provinces');
  var response = await http.get(url);
  var result = json.decode(response.body);
  return result;
}
