package com.example.flutter_midterm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
